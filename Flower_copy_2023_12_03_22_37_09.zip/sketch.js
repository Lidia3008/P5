function setup() {
  const size = min(windowWidth, windowHeight);
  createCanvas(size, size);
  colorMode(HSL,1)
  noStroke();
}
function cosn(v){
  return cos(v * TWO_PI) * 0.5 + 0.5
}
function invCosn(v){
  return 1 - cosn(v);
}
const radius =  Math.sqrt(0.5);
const PHI = (1 + Math.sqrt(5)) / 2;
const dotSize = 0.1;

let t;
const frames = 1000;
function draw() {
  t = fract(frameCount / frames);
  // t = mouseX / width;

let mySound;
function preload() {
  soundFormats('8.wav');
  mySound = loadSound('8.wav');
}

function canvasPressed() {
  // playing a sound file on a user gesture
  // is equivalent to `userStartAudio()`
  mySound.play();
}  
  scale(width, height);
  background(0);
  fill(1);
  
  const count = 1500 * t;
  for(let i = 0; i < count * t; i++){
    const f = i / count;
    const a  = i * PHI;
    const dist = f *radius;
    
    const x =0.5 + cos(a *TWO_PI)*dist;
    const y =0.5 + sin(a *TWO_PI)*dist;
    
    const sig = pow(cosn(f + t * 6), 2);
    const r =sig * f * dotSize;
    
    const hue = fract( f * 0.5 + t); 
    const sat = 1;
    const light = 0.5 * sig + 0.25;
    const clr = color(hue, sat, light);
    fill(clr);
    
    circle(x, y, r);
  }
}

// let mySound;
// function preload() {
//   soundFormats('8.wav');
//   mySound = loadSound('8.wav');
// }

// function canvasPressed() {
//   // playing a sound file on a user gesture
//   // is equivalent to `userStartAudio()`
//   mySound.play();
// }